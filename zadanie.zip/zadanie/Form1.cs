﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        bool czysc = false;
        int klikklik = 0;
        bool con = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (czysc == true)
            {
                txtWynik.Text = "";
                czysc = false;
            }
        }

        private void rbtnOdejmowanie_CheckedChanged(object sender, EventArgs e)
        {
            if (czysc == true)
            {
                txtWynik.Text = "";
                czysc = false;
            }
        }

        private void txtLiczba1_TextChanged(object sender, EventArgs e)
        {
            if (czysc == true)
            {
                txtWynik.Text = "";
                czysc = false;
            }
        }

        private void txtWynik_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnPolicz_Click(object sender, EventArgs e)
        {
            con = true;
            bool nat = false;
            decimal w = 0;
            //             if ((int)txtLiczba1.Text - txtLiczba1.Text != 0)
            //    MessageBox.Show("podaj liczbe calkowita");
            /*
            int liczba1 = 0;// Int32.Parse(txtLiczba1.Text);
            int liczba2 = Int32.Parse(txtLiczba2.Text);
            bool efekt = Int32.TryParse(txtLiczba1.Text, out liczba1);
            if (efekt != true)
                MessageBox.Show("numString is not a valid long");
            */
            decimal liczba1 = 0;
            decimal liczba2 = 0;

           
           
                bool canConvert = decimal.TryParse(txtLiczba1.Text, out liczba1);
                if (canConvert != true)
                    MessageBox.Show("blad - wpisz liczbe");
                bool canConvert1 = decimal.TryParse(txtLiczba2.Text, out liczba2);
                if (canConvert1 != true)
                    MessageBox.Show("blad - wpisz liczbe");
            
                if (klikklik % 2 == 0)
                 {
                nat = true;
                if (liczba1%1 != 0 || liczba2%1 != 0)
                {
                    MessageBox.Show("blad - wpisz liczbe calkowita");
                    con = false;
                   
                }
                 }


            if (con == true)
            {
                if (rbtnDodawanie.Checked)
                {
                    w = liczba1 + liczba2;
                    txtWynik.Text = w + "";
                    czysc = true;
                }
                if (rbtnOdejmowanie.Checked)
                {
                    w = liczba1 - liczba2;
                    txtWynik.Text = w + "";
                    czysc = true;
                }
                if (rbtnDzielenie.Checked)
                {
                    if (liczba2 == 0)
                        MessageBox.Show("blad - nie dziel przez 0");
                    else
                    {
                        w = liczba1 / liczba2;
                        txtWynik.Text = w + "";
                        czysc = true;
                    }


                }
                if (rbtnMnozenie.Checked)
                {
                    w = liczba1 * liczba2;
                    txtWynik.Text = w + "";
                    czysc = true;
                }

                if (nat == true)
                {
                    w = w - w % 1;
                    txtWynik.Text = w + "";
                }
            }
            /*
            if (rbtnDodawanie.Checked)
            {
                w = liczba1 + liczba2;
                txtWynik.Text = w +"";
                czysc = true;
            }
            if (rbtnOdejmowanie.Checked)
            {
                w = liczba1 - liczba2;
                txtWynik.Text = w + "";
                czysc = true;
            }
            if (rbtnDzielenie.Checked)
            {
                if (liczba2 == 0)
                    MessageBox.Show("blad - nie dziel przez 0");
                else
                {
                    w = liczba1 / liczba2;
                    txtWynik.Text = w + "";
                    czysc = true;
                }


            }
            if (rbtnMnozenie.Checked)
            {
                w = liczba1 * liczba2;
                txtWynik.Text = w + "";
                czysc = true;
            }
            */
        }

        private void rbtnDodawanie_CheckedChanged(object sender, EventArgs e)
        {
            if (czysc == true)
            {
                txtWynik.Text = "";
                czysc = false;
            }
        }

        private void rbtnDzielenie_CheckedChanged(object sender, EventArgs e)
        {
            if (czysc == true)
            {
                txtWynik.Text = "";
                czysc = false;
            }
        }

        private void rbtnMnozenie_CheckedChanged(object sender, EventArgs e)
        {
            if (czysc == true)
            {
                txtWynik.Text = "";
                czysc = false;
            }
        }

        private void chcBoxLN_CheckedChanged(object sender, EventArgs e)
        {
            klikklik = klikklik +1;
            txtWynik.Text = "";
        }
        // wprowdzenie try catch
    }
}
