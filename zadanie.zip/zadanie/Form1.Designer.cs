﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbtnDodawanie = new System.Windows.Forms.RadioButton();
            this.rbtnOdejmowanie = new System.Windows.Forms.RadioButton();
            this.rbtnDzielenie = new System.Windows.Forms.RadioButton();
            this.rbtnMnozenie = new System.Windows.Forms.RadioButton();
            this.txtWynik = new System.Windows.Forms.TextBox();
            this.txtLiczba1 = new System.Windows.Forms.TextBox();
            this.txtLiczba2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnPolicz = new System.Windows.Forms.Button();
            this.chcBoxLN = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // rbtnDodawanie
            // 
            this.rbtnDodawanie.AutoSize = true;
            this.rbtnDodawanie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rbtnDodawanie.Location = new System.Drawing.Point(131, 68);
            this.rbtnDodawanie.Name = "rbtnDodawanie";
            this.rbtnDodawanie.Size = new System.Drawing.Size(36, 24);
            this.rbtnDodawanie.TabIndex = 0;
            this.rbtnDodawanie.TabStop = true;
            this.rbtnDodawanie.Text = "+";
            this.rbtnDodawanie.UseVisualStyleBackColor = true;
            this.rbtnDodawanie.CheckedChanged += new System.EventHandler(this.rbtnDodawanie_CheckedChanged);
            // 
            // rbtnOdejmowanie
            // 
            this.rbtnOdejmowanie.AutoSize = true;
            this.rbtnOdejmowanie.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rbtnOdejmowanie.Location = new System.Drawing.Point(175, 91);
            this.rbtnOdejmowanie.Name = "rbtnOdejmowanie";
            this.rbtnOdejmowanie.Size = new System.Drawing.Size(34, 28);
            this.rbtnOdejmowanie.TabIndex = 1;
            this.rbtnOdejmowanie.TabStop = true;
            this.rbtnOdejmowanie.Text = "-";
            this.rbtnOdejmowanie.UseVisualStyleBackColor = true;
            this.rbtnOdejmowanie.CheckedChanged += new System.EventHandler(this.rbtnOdejmowanie_CheckedChanged);
            // 
            // rbtnDzielenie
            // 
            this.rbtnDzielenie.AutoSize = true;
            this.rbtnDzielenie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rbtnDzielenie.Location = new System.Drawing.Point(174, 68);
            this.rbtnDzielenie.Name = "rbtnDzielenie";
            this.rbtnDzielenie.Size = new System.Drawing.Size(31, 24);
            this.rbtnDzielenie.TabIndex = 3;
            this.rbtnDzielenie.TabStop = true;
            this.rbtnDzielenie.Text = "/";
            this.rbtnDzielenie.UseVisualStyleBackColor = true;
            this.rbtnDzielenie.CheckedChanged += new System.EventHandler(this.rbtnDzielenie_CheckedChanged);
            // 
            // rbtnMnozenie
            // 
            this.rbtnMnozenie.AutoSize = true;
            this.rbtnMnozenie.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.rbtnMnozenie.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rbtnMnozenie.Location = new System.Drawing.Point(131, 95);
            this.rbtnMnozenie.Name = "rbtnMnozenie";
            this.rbtnMnozenie.Size = new System.Drawing.Size(35, 28);
            this.rbtnMnozenie.TabIndex = 4;
            this.rbtnMnozenie.TabStop = true;
            this.rbtnMnozenie.Text = "*";
            this.rbtnMnozenie.UseVisualStyleBackColor = true;
            this.rbtnMnozenie.CheckedChanged += new System.EventHandler(this.rbtnMnozenie_CheckedChanged);
            // 
            // txtWynik
            // 
            this.txtWynik.Location = new System.Drawing.Point(356, 72);
            this.txtWynik.MaxLength = 5;
            this.txtWynik.Multiline = true;
            this.txtWynik.Name = "txtWynik";
            this.txtWynik.ReadOnly = true;
            this.txtWynik.Size = new System.Drawing.Size(68, 32);
            this.txtWynik.TabIndex = 5;
            this.txtWynik.TextChanged += new System.EventHandler(this.txtWynik_TextChanged);
            // 
            // txtLiczba1
            // 
            this.txtLiczba1.Location = new System.Drawing.Point(26, 73);
            this.txtLiczba1.MaxLength = 10;
            this.txtLiczba1.Multiline = true;
            this.txtLiczba1.Name = "txtLiczba1";
            this.txtLiczba1.Size = new System.Drawing.Size(68, 31);
            this.txtLiczba1.TabIndex = 6;
            this.txtLiczba1.TextChanged += new System.EventHandler(this.txtLiczba1_TextChanged);
            // 
            // txtLiczba2
            // 
            this.txtLiczba2.Location = new System.Drawing.Point(245, 72);
            this.txtLiczba2.MaxLength = 10;
            this.txtLiczba2.Multiline = true;
            this.txtLiczba2.Name = "txtLiczba2";
            this.txtLiczba2.Size = new System.Drawing.Size(68, 32);
            this.txtLiczba2.TabIndex = 7;
            this.txtLiczba2.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(319, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 31);
            this.label1.TabIndex = 8;
            this.label1.Text = "=";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(119, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "wybierz dzialanie";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "podaj 1 liczbe";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(245, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "podaj 2 liczbe";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(375, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "wynik";
            // 
            // btnPolicz
            // 
            this.btnPolicz.BackColor = System.Drawing.Color.GhostWhite;
            this.btnPolicz.Location = new System.Drawing.Point(356, 124);
            this.btnPolicz.Name = "btnPolicz";
            this.btnPolicz.Size = new System.Drawing.Size(68, 28);
            this.btnPolicz.TabIndex = 13;
            this.btnPolicz.Text = "policz";
            this.btnPolicz.UseVisualStyleBackColor = false;
            this.btnPolicz.Click += new System.EventHandler(this.btnPolicz_Click);
            // 
            // chcBoxLN
            // 
            this.chcBoxLN.AutoSize = true;
            this.chcBoxLN.Location = new System.Drawing.Point(26, 131);
            this.chcBoxLN.Name = "chcBoxLN";
            this.chcBoxLN.Size = new System.Drawing.Size(114, 17);
            this.chcBoxLN.TabIndex = 14;
            this.chcBoxLN.Text = "liczby niecalkowite";
            this.chcBoxLN.UseVisualStyleBackColor = true;
            this.chcBoxLN.CheckedChanged += new System.EventHandler(this.chcBoxLN_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(467, 177);
            this.Controls.Add(this.chcBoxLN);
            this.Controls.Add(this.btnPolicz);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtLiczba2);
            this.Controls.Add(this.txtLiczba1);
            this.Controls.Add(this.txtWynik);
            this.Controls.Add(this.rbtnMnozenie);
            this.Controls.Add(this.rbtnDzielenie);
            this.Controls.Add(this.rbtnOdejmowanie);
            this.Controls.Add(this.rbtnDodawanie);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "KALKULATOR";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbtnDodawanie;
        private System.Windows.Forms.RadioButton rbtnOdejmowanie;
        private System.Windows.Forms.RadioButton rbtnDzielenie;
        private System.Windows.Forms.RadioButton rbtnMnozenie;
        private System.Windows.Forms.TextBox txtWynik;
        private System.Windows.Forms.TextBox txtLiczba1;
        private System.Windows.Forms.TextBox txtLiczba2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnPolicz;
        private System.Windows.Forms.CheckBox chcBoxLN;
    }
}

